package com.niit.ecart.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.ecart.bean.Product;

@Repository
public class ProductDAO 
{
	public List<Product> getAllProducts()
	{
		
		List<Product> list = new ArrayList<Product>();
		
		Product p1= new Product();
		p1.setId("PRO_MOB");
		p1.setName("Mobile");
		p1.setPrice("25000");
		p1.setQuantity("2");
		p1.setDescription("This is Mobile Category");
		
		list.add(p1);
		
		
		p1= new Product();
		p1.setId("PRO_EL");
		p1.setName("TeleVision");
		p1.setPrice("78000.65");
		p1.setQuantity("5");
		p1.setDescription("This is Electronics Category");
		
		list.add(p1);
		
		
		p1= new Product();
		p1.setId("PRO_HK");
		p1.setName("GlassJuicer");
		p1.setPrice("600.23");
		p1.setQuantity("10");
		p1.setDescription("This is House Keeping Category");
		
		list.add(p1);
		
		return list;
	}
}
